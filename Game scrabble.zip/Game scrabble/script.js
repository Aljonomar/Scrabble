const tilePool = [
    {letter: 'A', points: 1, count: 9},
    {letter: 'B', points: 3, count: 2},
    {letter: 'C', points: 3, count: 2},
    {letter: 'D', points: 2, count: 4},
    {letter: 'E', points: 1, count: 12},
    {letter: 'F', points: 4, count: 2},
    {letter: 'G', points: 2, count: 3},
    {letter: 'H', points: 4, count: 2},
    {letter: 'I', points: 1, count: 9},
    {letter: 'L', points: 1, count: 4},
    {letter: 'M', points: 3, count: 2},
    {letter: 'N', points: 1, count: 6},
    {letter: 'O', points: 1, count: 8},
    {letter: 'P', points: 3, count: 2},
    {letter: 'R', points: 1, count: 6},
    {letter: 'S', points: 1, count: 4},
    {letter: 'T', points: 1, count: 6},
    {letter: 'U', points: 1, count: 4},
    {letter: 'V', points: 4, count: 2},
    {letter: 'W', points: 4, count: 2},
    {letter: 'Y', points: 4, count: 2}
];

let bag = [];
let userRack = [];
let botRack = [];
let userScore = 0;
let botScore = 0;
let boardState = Array(8).fill(null).map(() => Array(8).fill(null));
let placedThisTurn = [];
let isMyTurn = true;
let currentDifficulty = 'medium';

function setDifficulty(level) {
    currentDifficulty = level;
    document.querySelectorAll('.diff-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    logMessage(`⚙️ Difficulty set to ${level.toUpperCase()}`);
}

function initBag() {
    bag = [];
    tilePool.forEach(item => {
        for(let i = 0; i < item.count; i++) {
            bag.push({ letter: item.letter, points: item.points, id: Math.random().toString(36).substr(2, 9) });
        }
    });
    bag.sort(() => Math.random() - 0.5);
}

function drawTiles(rack, count) {
    while(rack.length < count && bag.length > 0) {
        rack.push(bag.pop());
    }
}

function logMessage(msg) {
    const logBox = document.getElementById('game-log');
    logBox.innerHTML += `<div>> ${msg}</div>`;
    logBox.scrollTop = logBox.scrollHeight;
}

function showScorePopup(text, color = "#f4d06f") {
    const popup = document.getElementById('score-popup');
    popup.innerText = text;
    popup.style.background = color;
    popup.style.color = color === "#f4d06f" ? "#1a1a2e" : "#fff";
    popup.classList.add('show');
    setTimeout(() => {
        popup.classList.remove('show');
    }, 1500);
}

function updateTurnUI() {
    const userProfile = document.getElementById('user-profile');
    const botProfile = document.getElementById('bot-profile');
    const userBadge = document.getElementById('user-turn-badge');
    const botBadge = document.getElementById('bot-turn-badge');

    if (isMyTurn) {
        userProfile.classList.add('active-turn');
        botProfile.classList.remove('active-turn');
        userBadge.classList.remove('hidden');
        botBadge.classList.add('hidden');
    } else {
        userProfile.classList.remove('active-turn');
        botProfile.classList.add('active-turn');
        userBadge.classList.add('hidden');
        botBadge.classList.remove('hidden');
    }
}

function renderBoard() {
    const boardEl = document.getElementById('board');
    boardEl.innerHTML = '';
    for(let r=0; r<8; r++) {
        for(let c=0; c<8; c++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.dataset.row = r;
            cell.dataset.col = c;
            
            if((r === 0 || r === 7) && (c === 3 || c === 4)) { cell.classList.add('dw'); cell.innerText = "DW"; }
            else if((r === 3 || r === 4) && (c === 0 || c === 7)) { cell.classList.add('dw'); cell.innerText = "DW"; }
            else if((r === 2 || r === 5) && (c === 2 || c === 5)) { cell.classList.add('dl'); cell.innerText = "DL"; }

            cell.setAttribute('ondragover', 'allowDrop(event)');
            cell.setAttribute('ondrop', 'dropToBoard(event)');

            if(boardState[r][c]) {
                const tileData = boardState[r][c];
                const tileDiv = createTileElement(tileData, isMyTurn);
                cell.appendChild(tileDiv);
            }

            boardEl.appendChild(cell);
        }
    }
}

function createTileElement(tileData, draggable = true) {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.draggable = draggable;
    tile.id = tileData.id;
    tile.innerHTML = `${tileData.letter}<span class="points">${tileData.points}</span>`;
    tile.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', tileData.id);
    });
    return tile;
}

function renderRack() {
    const rackEl = document.getElementById('rack');
    rackEl.innerHTML = '';
    userRack.forEach(tileData => {
        rackEl.appendChild(createTileElement(tileData, isMyTurn));
    });
}

function allowDrop(ev) {
    ev.preventDefault();
}

function dropToBoard(ev) {
    ev.preventDefault();
    if (!isMyTurn) return;
    
    const cell = ev.target.closest('.cell');
    if(!cell) return;
    
    const r = parseInt(cell.dataset.row);
    const c = parseInt(cell.dataset.col);

    if(boardState[r][c] !== null) return;

    const tileId = ev.dataTransfer.getData('text/plain');
    const tileIndex = userRack.findIndex(t => t.id === tileId);
    
    if(tileIndex > -1) {
        const tileData = userRack.splice(tileIndex, 1)[0];
        boardState[r][c] = tileData;
        placedThisTurn.push({r, c, tileData});
        renderBoard();
        renderRack();
    }
}

function dropToRack(ev) {
    ev.preventDefault();
    if (!isMyTurn) return;
    
    const tileId = ev.dataTransfer.getData('text/plain');
    const placedIndex = placedThisTurn.findIndex(p => p.tileData.id === tileId);
    
    if(placedIndex > -1) {
        const {r, c, tileData} = placedThisTurn.splice(placedIndex, 1)[0];
        boardState[r][c] = null;
        userRack.push(tileData);
        renderBoard();
        renderRack();
    }
}

function validateAndScoreWord(tilesPlaced) {
    return tilesPlaced.length >= 2;
}

function submitWord() {
    if (!isMyTurn) return;
    if(placedThisTurn.length === 0) {
        alert("Place at least one letter on the board!");
        return;
    }

    const tileElements = document.querySelectorAll('.board .tile');
    const isCorrect = validateAndScoreWord(placedThisTurn);

    if (!isCorrect) {
        tileElements.forEach(t => t.classList.add('invalid-red'));
        logMessage("❌ Invalid word configuration! Try placing at least 2 connected letters.");
        showScorePopup("Invalid Word!", "#e74c3c");
        
        setTimeout(() => {
            tileElements.forEach(t => t.classList.remove('invalid-red'));
        }, 1200);
        return;
    }

    tileElements.forEach(t => t.classList.add('valid-green'));

    let turnScore = 0;
    placedThisTurn.forEach(p => {
        let mPoints = p.tileData.points;
        if((p.r === 0 || p.r === 7) && (p.c === 3 || p.c === 4)) turnScore += mPoints * 2;
        else if((p.r === 3 || p.r === 4) && (p.c === 0 || p.c === 7)) turnScore += mPoints * 2;
        else if((p.r === 2 || p.r === 5) && (p.c === 2 || p.c === 5)) turnScore += mPoints * 2;
        else turnScore += mPoints;
    });

    userScore += turnScore;
    document.getElementById('user-score').innerText = userScore;
    
    logMessage(`✅ Fammy scored +${turnScore} points!`);
    showScorePopup(`+${turnScore} PTS!`, "#2ecc71");

    setTimeout(() => {
        placedThisTurn = [];
        drawTiles(userRack, 7);
        renderBoard();
        renderRack();

        isMyTurn = false;
        updateTurnUI();
        setTimeout(botTurn, 1200);
    }, 1000);
}

function passTurn() {
    if (!isMyTurn) return;
    
    placedThisTurn.forEach(p => {
        boardState[p.r][p.c] = null;
        userRack.push(p.tileData);
    });
    placedThisTurn = [];
    renderBoard();
    renderRack();
    logMessage("Fammy passed the turn.");
    
    isMyTurn = false;
    updateTurnUI();
    setTimeout(botTurn, 1000);
}

function botTurn() {
    logMessage("🤖 ScrabbleBot is thinking...");
    
    // Adjust bot behavior based on difficulty
    let multiplier = 1;
    let delay = 1500;
    if (currentDifficulty === 'easy') { multiplier = 1; delay = 2000; }
    else if (currentDifficulty === 'medium') { multiplier = 2; delay = 1500; }
    else if (currentDifficulty === 'hard') { multiplier = 3; delay = 1000; }

    setTimeout(() => {
        if(botRack.length > 0) {
            let randomTile = botRack.pop();
            let botPoints = randomTile.points * multiplier;
            botScore += botPoints;
            document.getElementById('bot-score').innerText = botScore;
            logMessage(`🤖 ScrabbleBot played '${randomTile.letter}' (${currentDifficulty}) for +${botPoints} points.`);
            showScorePopup(`Bot scored +${botPoints}`, "#e74c3c");
            drawTiles(botRack, 1);
        } else {
            logMessage("🤖 ScrabbleBot passes.");
        }

        isMyTurn = true;
        updateTurnUI();
        renderBoard();
        renderRack();
    }, delay);
}

function initGame() {
    initBag();
    drawTiles(userRack, 7);
    drawTiles(botRack, 7);
    updateTurnUI();
    renderBoard();
    renderRack();
}

initGame();